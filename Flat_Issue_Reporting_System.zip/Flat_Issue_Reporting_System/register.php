<?php
    session_start();
    require "MyClass.php";
    $obj = new MyClass();
    //$conn = $obj->DBconnection();

    if(isset($_POST['register']))
    {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $passwd = $_POST['passwd'];
        $mobile = $_POST['mobile'];
        $roll = "owner";
        $hash_pwd = password_hash($passwd,PASSWORD_DEFAULT);

        $qry = $obj->register($username,$email,$hash_pwd,$mobile,$roll);

        if($qry)
        {
            echo "Insert Record Successfully...";
            header("location:login.php");
        }
        else{
            echo "Data Not Inserted.......";
        }
    }

?>
<html>
<head>
    <title>Apartment Issue Reporting System </title>
    <?php
    require "stylesheet.php";
    ?>
</head>
<body>
<!-- Start Navbar...... -->
<nav class="navbar navbar-dark bg-dark" style="margin-bottom:0px">
    <a class="navbar-brand" href="home.php">Issue Reporting System</a>
    <div>
        <ul class="nav" style="margin-left: 750px">
            <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
            <li class="nav-item"><a class="nav-link" href="post.php">Post</a></li>
            <li class="nav-item"><a class="nav-link" href="blog.php">Blog</a></li>
        </ul>
    </div>
</nav>
<!--End Navbar......-->


<div class="container-fluid my-2 py-4" style="background-color:#e9ecef;">
    <div class="container w-50 p-5 mt-5">

        <form method="post" action="">
            <h2 class="py-2">Registration</h2>

            <div class="form-group">
                <label for="exampleInputUsername">User Name</label>
                <input type="text" class="form-control" id="username" name="username" aria-describedby="emailHelp"
                       placeholder="Enter User Name" required>
            </div>

            <div class="form-group">
                <label for="exampleInputEmail1">Email address</label>
                <input type="email" class="form-control" name="email" id="email1" aria-describedby="emailHelp"
                       placeholder="Enter email" required>
            </div>

            <div class="form-group">
                <label for="exampleInputPassword1">Password</label>
                <input type="password" class="form-control" name="passwd" id="password" placeholder="Enter Password" required>
            </div>

            <div class="form-group">
                <label for="exampleInputContact">Mobile</label>
                <input type="number" class="form-control" name="mobile" id="exampleInputnumber" placeholder="Enter Mobile Number" required>
            </div>

            <a>Already a Account ? <a href="login.php">Login</a></a>
            <a style="float: right"  href="forgotpasswd.php">Forgot Password </a><br><br>
            <button type="submit" id="register" name="register" class="btn btn-primary">Sign Up</button>
        </form>
    </div>
</div>

<!--Footer Start -->
<nav class="navbar navbar-dark bg-dark">

</nav>
<!--Footer End -->

</body>
</html>