<?php

    session_start();
    require "MyClass.php";
    $obj = new MyClass();

    if(isset($_REQUEST["reportid"]))
    {
        try
        {
            $reportid = $_REQUEST['reportid'];
            $comment = $_POST["cmt"];

            $query = $obj->conn->prepare("insert into feedback(reportid,comment) values('$reportid','$comment')");
            $query->execute();
        }
        catch(PDOException $e)
        {
            $e->getMessage();
        }
    }
