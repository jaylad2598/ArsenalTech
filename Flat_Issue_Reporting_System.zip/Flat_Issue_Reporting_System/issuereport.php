<?php
    session_start();
    require "MyClass.php";
    $obj = new MyClass();

    if (!isset($_SESSION['userid']))
    {
        header('location: login.php');
    }

    if(isset($_POST['submit']))
    {
        $ownername = $_POST['ownername'];
        $flatnumber = $_POST['flatnumber'];
        $contact = $_POST['contact'];
        $title = $_POST['title'];
        $description = $_POST['description'];
        $userid = $_SESSION['userid'];
        $status = "open";

        $qry = $obj->issuereport($ownername,$flatnumber,$contact,$title,$description,$userid,$status);

        if($qry)
        {
            echo "Insert Record Successfully...";
            header("location:home.php");
        }
        else{
            echo "Record Not Inserted Successfully...";
        }
    }
?>
<html>
<head>
    <title>Apartment Issue Reporting System </title>
    <?php
        require "stylesheet.php";
    ?>
</head>
<body>
<!-- Start Navbar...... -->
<nav class="navbar navbar-dark bg-dark" style="margin-bottom:0px">
    <a class="navbar-brand" href="home.php">Issue Reporting System</a>
    <div>
        <ul class="nav" style="margin-left: 750px">

            <li class="nav-item"><a class="nav-link" href="post.php">Post</a></li>
            <li class="nav-item"><a class="nav-link" href="blog.php">Blog</a></li>

            <?php
            if (isset($_SESSION['userid']))
            {
                echo "<a class='btn btn-danger' href='logout.php'>Logout</a></li>";
            }
            else{
                echo "<a class='btn btn-primary' href='login.php'>Login</a></li>";
            }
            ?>

        </ul>
    </div>
</nav>
<!--End Navbar......-->

<div class="container-fluid my-2 py-4" style="background-color:#e9ecef;">
    <div class="container w-50 p-5 mt-5">

        <form method="post" action="">
            <h2 class="py-2">Issue Report</h2>

            <div class="form-group">
                <label for="exampleInputOwnerName">Owner Name</label>
                <input type="text" class="form-control" name="ownername" id="exampleInputOwnerName"
                       placeholder="Enter Owner Name">
            </div>

            <div class="form-group">
                <label for="exampleInputFlatNumber">Flat Number</label>
                <input type="text" class="form-control" name="flatnumber" id="exampleInputFlatNumber"
                       placeholder="Enter Flat Number">
            </div>

            <div class="form-group">
                <label for="exampleInputContact">Contact Number</label>
                <input type="number" class="form-control" name="contact" id="exampleInputContact"
                       placeholder="Enter Mobile Number">
            </div>

            <div class="form-group">
                <label for="exampleInputIssue">Issue Title</label>
                <input type="text" class="form-control" name="title" id="exampleInputIssue" placeholder="Enter Issue Title">
            </div>

            <div class="form-group">
                <label for="exampleInputDescription">Description</label>
                <input type="text" class="form-control" name="description" id="exampleInputDescription" placeholder="Enter Issue Description">
            </div>

            <a>Already a Account ? <a href="login.php">Login</a></a>
            <a style="float: right"  href="forgotpasswd.php">Forgot Password </a><br><br>
            <button type="submit" name="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
</div>

<!--Footer Start -->
<nav class="navbar navbar-dark bg-dark">

</nav>
<!--Footer End -->

</body>
</html>