-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 09, 2021 at 02:40 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `flatissue`
--

-- --------------------------------------------------------

--
-- Table structure for table `issuereport`
--

CREATE TABLE `issuereport` (
  `reportid` int(11) NOT NULL,
  `ownername` varchar(255) NOT NULL,
  `flatnumber` int(11) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `userid` int(11) NOT NULL,
  `reportdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `issuereport`
--

INSERT INTO `issuereport` (`reportid`, `ownername`, `flatnumber`, `contact`, `title`, `description`, `userid`, `reportdate`, `status`) VALUES
(1, 'jay', 101, '9874563210', 'Water Problem', 'There is lot\'s of issue with water in our flat.Plaese try to solve it as soon as possible', 2, '2021-03-09 11:59:59', 'open'),
(2, 'parth', 106, '9874563210', 'Noice Poluction', 'There are lot\'s of noice is out apartment', 5, '2021-03-09 12:40:36', 'open');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `passwd` varchar(255) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `createdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `roll` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `username`, `email`, `passwd`, `mobile`, `createdate`, `roll`) VALUES
(2, 'jay12', 'jaylad432@gmail.com', '$2y$10$0IxLhOnYsRypAUc5mQnNmuCgU19V2hcfA1W8LC7h2djVSib.k6WTi', '9630125478', '2021-03-09 10:08:26', 'owner'),
(3, 'darsh', 'jay@jay.com', '$2y$10$KtTCfKt/nb8evGwwCGzuu.8yWQAwWfz2E6YXhz3SGcJ2ZTySgMu6a', '9632514750', '2021-03-09 10:49:55', 'owner'),
(4, 'admin', 'admin@gmail.com', '$2y$10$SzvG9M2LiM3kPWtA1Uqs5utO2i44DHZFemIAUneAKKoQNMNK2vAWa', '9601825142', '2021-03-09 12:26:37', 'admin'),
(5, 'parth', 'jay@jay.com', '$2y$10$1G4rzwWET1b.nouwluaB5eXTEyvwsF..uO1ZWY22MuXsY9zVI5poa', '9825014205', '2021-03-09 12:39:55', 'owner');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `issuereport`
--
ALTER TABLE `issuereport`
  ADD PRIMARY KEY (`reportid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `issuereport`
--
ALTER TABLE `issuereport`
  MODIFY `reportid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
