<?php
session_start();
require "MyClass.php";
$obj = new MyClass();

$query = $obj->conn->prepare("select * from issuereport");
$query->execute();
$result = $query->setFetchMode(PDO::FETCH_ASSOC);

if(isset($_POST['feedback']))
{
    header("Location:feedback.php?id=".$_POST['feedback']);
}

?>
<html>
<head>
    <title>Apartment Issue Reporting System </title>
    <?php
    require "stylesheet.php";
    ?>
</head>
<body>
<!-- Start Navbar...... -->
<nav class="navbar navbar-dark bg-dark" style="margin-bottom:0px">
    <a class="navbar-brand" href="home.php">Issue Reporting System</a>
    <div>
        <ul class="nav" style="margin-left: 750px">
            <li class="nav-item"><a class="nav-link" href="ownerdetails.php">IssueDetails</a></li>
            <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
        </ul>
    </div>
</nav>
<!--End Navbar......-->
<h1 style="text-align: center">Welcome to Admin Page</h1>

<!--Footer Start -->
<nav class="navbar navbar-dark bg-dark">

</nav>
<!--Footer End -->

</body>
</html>