<?php
session_start();
require "MyClass.php";
$obj = new MyClass();

if(isset($_REQUEST['reportid']))
{
//    ech
        $reportid = $_REQUEST['reportid'];
        $status = $_POST['status'];


        $query =$obj->conn->prepare("update issuereport set status = '".$status."' where reportid='".$reportid."'");
        $query->execute();


    }