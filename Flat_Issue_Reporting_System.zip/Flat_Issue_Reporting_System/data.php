<?php
    session_start();
    require "MyClass.php";
    $obj = new MyClass();

    if (!isset($_SESSION['userid']))
    {
        header('location: login.php');
    }

$userid = $_SESSION['userid'];
    $query = $obj->conn->prepare("select * from issuereport where userid = '".$userid."'");
    $query->execute();
    $result = $query->setFetchMode(PDO::FETCH_ASSOC);
?>

<html>
<head>
    <title>Apartment Issue Reporting System </title>
    <?php
    require "stylesheet.php";
    ?>
</head>
<body>
<!-- Start Navbar...... -->
<nav class="navbar navbar-dark bg-dark" style="margin-bottom:0px">
    <a class="navbar-brand" href="home.php">Issue Reporting System</a>
    <div>
        <ul class="nav" style="margin-left: 750px">
            <li class="nav-item"><a class="nav-link" href="home.php">home</a></li>
            <li class="nav-item"><a class="nav-link" href="login.php">login</a></li>
        </ul>
    </div>
</nav>
<!--End Navbar......-->

<div style="margin:10px">
    <form method="post">
        <?php
        if(isset($result))
        {
            echo "<table class='table table-dark'>
               <tr>
                    <th>Id</th>
                    <th>Flat Number</th>
                    <th>Contact</th>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Report Date</th>
                    <th>Status</th>
                    
                </tr>";

            foreach($query->fetchAll() as $v)
            {
                echo "<tr>";
                echo "<td>".$v['reportid']."</td>";
                echo "<td>".$v['flatnumber']."</td>";
                echo "<td>".$v['contact']."</td>";
                echo "<td>".$v['title']."</td>";
                echo "<td>".$v['description']."</td>";
                echo "<td>".$v['reportdate']."</td>";
                echo "<td>".$v['status']."</td>";
                echo "</tr>";
            }
            echo "</table>";
        }
        ?>
    </form>
</div>

<!--Footer Start -->
<nav class="navbar navbar-dark bg-dark">

</nav>
<!--Footer End -->

</body>
</html>
