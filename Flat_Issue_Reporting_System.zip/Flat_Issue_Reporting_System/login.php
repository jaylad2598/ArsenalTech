<?php
    session_start();
    require "MyClass.php";
    $obj = new MyClass();

    if(isset($_POST['login']))
    {
        $username = $_POST['username'];
        $passwd = $_POST['passwd'];
        $qry = $obj->login($username,$passwd);
    }
?>
<html>
<head>
    <title>Apartment Issue Reporting System </title>
    <?php
    require "stylesheet.php";
    ?>
</head>
<body>
<!-- Start Navbar...... -->
<nav class="navbar navbar-dark bg-dark" style="margin-bottom:0px">
    <a class="navbar-brand" href="home.php">Issue Reporting System</a>
    <div>
        <ul class="nav" style="margin-left: 750px">
            <li class="nav-item"><a class="nav-link" href="register.php">Sign Up</a></li>
            <li class="nav-item"><a class="nav-link" href="home.php">Home</a></li>
        </ul>
    </div>
</nav>
<!--End Navbar......-->

    <div class="container-fluid my-2 py-4" style="background-color:#e9ecef;height:100%;">
        <div class="container w-50 p-5 mt-5">

            <form method="post" action="">
                <h2 class="py-2">Login</h2>
                    <div class="form-group">
                        <label for="exampleInputEmail1">User Name</label>
                        <input type="text" class="form-control" name="username" id="exampleInputEmail1" aria-describedby="emailHelp"
                        placeholder="Enter email" required>
                    </div>

                    <div class="form-group">
                        <label for="exampleInputPassword1">Password</label>
                        <input type="password" class="form-control" name="passwd" id="exampleInputPassword1" placeholder="Password" required>
                    </div>

                    <a>Don't Have a Account ? <a href="register.php">Sign Up</a></a>
                    <a style="float: right"  href="forgotpasswd.php">Forgot Password </a><br><br>
                    <button type="submit" name="login" class="btn btn-primary">Login</button>

            </form>
        </div>
    </div>

<!--Footer Start -->
<nav class="navbar navbar-dark bg-dark">

</nav>
<!--Footer End -->

</body>
</html>