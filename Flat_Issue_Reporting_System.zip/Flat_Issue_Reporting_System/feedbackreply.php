<?php

session_start();
require "MyClass.php";
$obj = new MyClass();

if(isset($_REQUEST["reportid"]))
{
    try
    {
        $reportid = $_REQUEST['reportid'];
        $reply = $_POST["reply"];

        $query = $obj->conn->prepare("insert into reply(reportid,reply) values('$reportid','$reply')");
        $query->execute();
    }
    catch(PDOException $e)
    {
        $e->getMessage();
    }
}