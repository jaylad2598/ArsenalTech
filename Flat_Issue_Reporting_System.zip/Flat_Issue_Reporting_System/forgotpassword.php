<html>
<head>
    <title>Raj Desai</title>
</head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="assets/js/blog.js"></script>
<link rel="stylesheet" href="css/blog.css">
<script
    src="https://code.jquery.com/jquery-3.4.1.min.js"
    integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
    crossorigin="anonymous"></script>

<body>
<?php
session_start();
    ?>
    <header>
        <h1>Blog</h1>
    </header>
    <!-- ________________________________________________________________________________________________--->
    <section id="forgotpassword">
        <div class="forgotpassword">

            <h2 style="font-size: 50px;text-align: center">Forgot Password</h2><br>
            <div class="container" id="verify">
                <form class="form" method="post">
                    <div class="row justify-content-center">
                        <div class="col-1 form-group">
                            <label for="emailtext" id="email" class="form-label" class="label">Email:-</label>
                        </div>
                        <div class="col-5 form-group">
                            <input type="email" name="email" class="form-control" id="emailtext" placeholder="Please Enter Registered Email" required><br>
                        </div>
                    </div>
                    <div class="row justify-content-center">
                        <button type="submit" class="btn btn-primary" name="forgotpassword" id="submit">verify</button>
                    </div>
                </form>
            </div>

        </div>
    </section>
    <!-- ________________________________________________________________________________________________--->
    <section id="image">
        <div class="image">

        </div>
    </section>

<?php
if(isset($_REQUEST["forgotpassword"])){
    require_once "mainclass.php";
    $obj=new blog();
    $email=$_REQUEST["email"];
    $f=$obj->validateemail($email);
    if($f==1){
require 'phpmailer/PHPMailerAutoload.php';
    $message=mt_rand(100000, 999999);

    $to_id = $email;

    $mail = new PHPMailer;

    $mail->isSMTP();

    $mail->Host = 'smtp.gmail.com';

    $mail->Port = 587;

    $mail->SMTPSecure = 'tls';

    $mail->SMTPAuth = true;

    $mail->Username = 'rajdesai4221@gmail.com';// add email

    $mail->Password = 'rajriyadesai';// add pass

    $mail->setFrom('rajdesai4221@gmail.com', 'arsenal tech');

    $mail->addReplyTo('rajdesai4221@gmail.com', 'arsenal tech');

    $mail->addAddress($to_id);

    $mail->Subject = 'OTP';

    $mail->msgHTML($message);

    if (!$mail->send()) {
        echo $mail->isError();
        $error = "Mailer Error: " . $mail->ErrorInfo;
    }
//    $email=$_REQUEST["email"];
//    $sub=$_REQUEST["sub"];
//    $msg=$_REQUEST["desc"];
//    $header='From: me@example.com';
//    mail($email,$sub,$msg,$header);
//    echo "Mail Send Successfully";
    echo "Mail Send Successfully";

        $_SESSION["id"]=$email;
        $i=$obj->insertotp($_SESSION["id"],$message);
        echo "<script type='text/javascript'>";
        echo "window.location.href='otp.php';";
        echo "</script>";
    }
    else{
        echo "<script type='text/javascript'>";
        echo "alert('Please check email');";
        echo "window.location.href='forgotpassword.php';";
        echo "</script>";
    }
}
?>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

</body>
</html>