<?php

    session_start();
    require "MyClass.php";
    $obj = new MyClass();
    $reportid = $_REQUEST['id'];

    $query = $obj->conn->prepare("select * from issuereport where reportid='".$reportid."'");
    $query->execute();
    $result = $query->setFetchMode(PDO::FETCH_ASSOC);

    $reportid = $_REQUEST['id'];
    $query1 = $obj->conn->prepare("select * from reply where reportid = '".$reportid."'");
    $query1->execute();
    $result1 = $query1->setFetchMode(PDO::FETCH_ASSOC);


    ?>
<html>
<head>
    <title>Apartment Issue Reporting System </title>
    <?php
        require "stylesheet.php";
    ?>
</head>
<body>
<!-- Start Navbar...... -->
<nav class="navbar navbar-dark bg-dark" style="margin-bottom:0px">
    <a class="navbar-brand" href="home.php">Issue Reporting System</a>
    <div>
        <ul class="nav" style="margin-left: 750px">
            <li class="nav-item"><a class="nav-link" href="adminhome.php">home</a></li>
            <li class="nav-item"><a class="nav-link" href="ownerdetails.php">Issue Report</a></li>
        </ul>
    </div>
</nav>
<!--End Navbar......-->

<h3 class="feedbackhead">Issue Feedback Form</h3>
<div class="divdata">
    <?php
    foreach($query->fetchAll() as $v)
    {
        echo "<tr class='feedbackdata'>";
        echo "<td class='td'> Flat Number Is : ".$v['flatnumber']."</td><br>";
        echo "<td class='td'> Issue Title Is : ".$v['title']."</td><br>";
        echo "<td class='td'> Issue Description : ".$v['description']."</td><br>";
        echo "</tr><br>";
    }
    ?>
    <!--<form action="#" method="post">-->
        <label>Status : </label>
        <select class="form-group" id="statuschange">
            <option value="Open">Open</option>
            <option>In Process</option>
            <option>Resolved</option>
        </select><br>
        Enter Feedback : <br><textarea id="issuefeedback"></textarea>
        <br><button id="submit" class="btn btn-primary btnclass">Submit</button>
    <!--</form>-->

        <p id="commentdata" class="style-comment"></p>

    <?php
        foreach ($query1->fetchAll() as $val)
        {
            echo "<p style='margin-left: 80px'>".$val['reply']."</p>";
        }
    ?>
</div>
<!--Footer Start -->
<nav class="navbar navbar-dark bg-dark">

</nav>
<!--Footer End -->
</body>
</html>
<script type="text/javascript">
    $(document).ready(function() {
        $("#submit").click(function() {
            $.ajax({
                type: "POST",
                url: "feedbackcomment.php",
                data: {reportid:<?php echo $reportid ?> , cmt: $("#issuefeedback").val()},
                success: function(response){
                    $.ajax({    //
                        type: "POST",
                        url: "getfeedbackcomment.php",
                        data: {reportid:<?php echo $reportid ?>},
                        success: function(response){
                            $("#commentdata").empty();
                            $("#commentdata").prepend(response);
                        }
                    });
                }
            });
        });
        $.ajax({    //
            type: "POST",
            url: "getfeedbackcomment.php",
            data: {reportid:<?php echo $reportid ?>},
            success: function(response){
                $("#commentdata").prepend(response);
            }
        });

        $("#statuschange").change(function() {
            //var status = $("#statuschange").val();
            //var id = <?php echo $reportid ?>;
            //console.log(status, id);
            //alert('lfnvbkj');
            $.ajax({
                type: "POST",
                url: "http://localhost/ArsenalTech/Flat_Issue_Reporting_System/updatestatus.php",
                data: {reportid:<?php echo $reportid ?>,status:$("#statuschange").val() },
                success: function(response){
                        alert("Updated Successfully.....");
                }
            });
        });

    });
</script>
