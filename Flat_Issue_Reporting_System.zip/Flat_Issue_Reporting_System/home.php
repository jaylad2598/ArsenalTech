<?php
    session_start();
    require "MyClass.php";
    $obj = new MyClass();



?>
<html>
<head>
    <title>Apartment Issue Reporting System </title>
    <?php
        require "stylesheet.php";
    ?>
</head>
    <body>
        <!-- Start Navbar...... -->
            <nav class="navbar navbar-dark bg-dark" style="margin-bottom:0px">
                <a class="navbar-brand" href="home.php">Issue Reporting System</a>
                <div>
                    <ul class="nav" style="margin-left: 570px">
                        <li class="nav-item"><a class="nav-link" href="issuereport.php">Report</a></li>
                        <li class="nav-item"><a class="nav-link" href="data.php">Data</a></li>
                        <li class="nav-item"><a class="nav-link" href="commentdata.php">feedback</a></li>

                        <?php
                        if (isset($_SESSION['userid']))
                        {
                            echo "<a class='btn btn-danger' href='logout.php'>Logout</a></li>";
                        }
                        else{
                            echo "<a class='btn btn-primary' href='login.php'>Login</a></li>";
                        }
                        ?>


                    </ul>
                </div>
            </nav>
        <!--End Navbar......-->

        <!--Start Slider......-->
        <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="d-block w-100" height="80%" src="flat1.jpg" alt="First slide">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" height="80%" src="flat2.jpg" alt="Second slide">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" height="80%" src="flat3.jpg" alt="Third slide">
                </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
        <!--End Slider -->

        <!--Footer Start -->
        <nav class="navbar navbar-dark bg-dark">

        </nav>
        <!--Footer End -->

    </body>
</html>