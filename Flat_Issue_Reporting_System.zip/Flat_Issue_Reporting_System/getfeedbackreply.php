<?php
session_start();
require "MyClass.php";
$obj = new MyClass();

if(isset($_REQUEST['reportid']))
{
    try{
        $reportid = $_REQUEST['reportid'];
        $query = $obj->conn->prepare("select * from reply where reportid = '".$reportid."'");

        $query->execute();

        foreach ($query->fetchALL() as $val)
        {
            echo "<p>".$val['reply']."</p>";
        }
    }
    catch(PDOException $ex)
    {
        $ex->getMessage();
    }
}