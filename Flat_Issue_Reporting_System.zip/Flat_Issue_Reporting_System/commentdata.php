<?php
    session_start();
    require "MyClass.php";
    $obj = new MyClass();

    if (!isset($_SESSION['userid']))
    {
        header('location: login.php');
    }

    $userid = $_SESSION['userid'];
    $query = $obj->conn->prepare("select * from issuereport where userid = '".$userid."'");
    $query->execute();
    $result = $query->setFetchMode(PDO::FETCH_ASSOC);


    if(isset($_POST['reply']))
    {
        header("Location:reply.php?id=".$_POST['reply']);
    }
?>

<html>
<head>
    <title>Apartment Issue Reporting System </title>
    <?php
    require "stylesheet.php";
    ?>
</head>
<body>
<!-- Start Navbar...... -->
<nav class="navbar navbar-dark bg-dark" style="margin-bottom:0px">
    <a class="navbar-brand" href="home.php">Issue Reporting System</a>
    <div>
        <ul class="nav" style="margin-left: 750px">
            <li class="nav-item"><a class="nav-link" href="home.php">home</a></li>
            <li class="nav-item"><a class="nav-link" href="login.php">login</a></li>
        </ul>
    </div>
</nav>
<!--End Navbar......-->

<div style="margin:10px">
    <form method="post">
        <?php
            foreach($query->fetchAll() as $v)
            {
                echo "<tr class='feedbackdata'>";
                echo "<td class='td'> Report Id  : " . $v['reportid'] . "</td><br>";
                echo "<td class='td'> Issue Title : " . $v['title'] . "</td><br>";
                echo "<td class='td'> Issue Description : " . $v['description'] . "</td><br><br>";
                $reportid = $v['reportid'];

                $feedbackQuery = $obj->conn->prepare("SELECT feedback.comment,feedback.reportid,issuereport.reportid,issuereport.userid from feedback,issuereport where feedback.reportid = issuereport.reportid AND feedback.reportid = $reportid");
                $feedbackQuery->execute();
                $feedbackResult = $feedbackQuery->setFetchMode(PDO::FETCH_ASSOC);

                foreach ($feedbackQuery->fetchAll() as $val)
                {
                    echo "<tr class='feedbackdata'>";
                    echo "<td class='td'> Issue Comment : " . $val['comment'] . "</td><br>";
                }
                echo "<br>";
                echo "<td><button type='submit' name='reply' class='btn btn-success' value=".$v['reportid'].">reply</button></td><br><hr>";
            }
        ?>
    </form>
</div>

<!--Footer Start -->
<nav class="navbar navbar-dark bg-dark">

</nav>
<!--Footer End -->
</body>
</html>

