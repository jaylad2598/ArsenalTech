<?php

    session_start();
    require "MyClass.php";
    $obj = new MyClass();
    $reportid = $_REQUEST['id'];

    $query = $obj->conn->prepare("SELECT feedback.feedbackid,feedback.comment,issuereport.reportdate,issuereport.title,issuereport.reportid,issuereport.description,issuereport.status FROM feedback,issuereport WHERE feedback.reportid = issuereport.reportid and feedback.reportid = '".$reportid."'");
    $query->execute();
    $result = $query->setFetchMode(PDO::FETCH_ASSOC);

?>

<html>
<head>
    <title>Apartment Issue Reporting System </title>
    <?php
    require "stylesheet.php";
    ?>
</head>
<body>
<!-- Start Navbar...... -->
<nav class="navbar navbar-dark bg-dark" style="margin-bottom:0px">
    <a class="navbar-brand" href="home.php">Issue Reporting System</a>
    <div>
        <ul class="nav" style="margin-left: 750px">
            <li class="nav-item"><a class="nav-link" href="home.php">home</a></li>
            <li class="nav-item"><a class="nav-link" href="ownerdetails.php">Issue Report</a></li>
        </ul>
    </div>
</nav>
<!--End Navbar......-->

<h3 class="feedbackhead">Issue Feedback Form</h3>
<div class="divdata">
    <?php
    $flag = 0;
    foreach($query->fetchAll() as $v)
    {
        if($flag == 0)
        {
            echo "<tr class='feedbackdata'>";
            echo "<td class='td'> Report Id  : ".$v['reportid']."</td><br>";
            echo "<td class='td'> Report Date : ".$v['reportdate']."</td><br>";
            echo "<td class='td'> Issue Title : ".$v['title']."</td><br>";
            echo "<td class='td'> Issue Description : ".$v['description']."</td><br>";
            echo "<td class='td'> Issue Status : ".$v['status']."</td><br>";
            echo "<td class='td'> Comment Is : ".$v['comment']."</td><br>";
            $flag += 1;
        }
        else{
            echo "<td class='td'>".$v['comment']."</td><br>";
        }
        echo "</tr><br>";
    }
    ?>
    <!--<form action="#" method="post">-->
    Enter Reply : <br><textarea id="feedbackreply"></textarea>
    <br><button id="submit" class="btn btn-primary btnclass">Submit</button>
    <!--</form>-->
    <p id="replydata" class="style-comment"></p>
</div>
<!--Footer Start -->
<nav class="navbar navbar-dark bg-dark">

</nav>
<!--Footer End -->
</body>
</html>

<script type="text/javascript">
    $(document).ready(function() {
        $("#submit").click(function() {
            $.ajax({
                type: "POST",
                url: "feedbackreply.php",
                data: {reportid:<?php echo $reportid ?> , reply: $("#feedbackreply").val()},
                success: function(response){
                    $.ajax({    //
                        type: "POST",
                        url: "getfeedbackreply.php",
                        data: {reportid:<?php echo $reportid ?>},
                        success: function(response){
                            $("#replydata").empty();
                            $("#replydata").prepend(response);
                        }
                    });
                }
            });
        });
        $.ajax({    //
            type: "POST",
            url: "getfeedbackreply.php",
            data: {reportid:<?php echo $reportid ?>},
            success: function(response){
                $("#replydata").prepend(response);
            }
        });
    });
</script>
